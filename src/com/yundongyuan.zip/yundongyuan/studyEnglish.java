package com.yundongyuan;

public interface studyEnglish {
    void studyEng();
}
